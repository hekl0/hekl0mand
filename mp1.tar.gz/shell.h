#ifndef _Shell_h
#define _Shell_h

#define Interpreter "hekl0mand"

#define ANSI_COLOR_GREEN "\x1b[32m"
#define ANSI_COLOR_BLUE "\x1b[36m"
#define ANSI_COLOR_RESET "\x1b[0m"

void Terminate();

#endif